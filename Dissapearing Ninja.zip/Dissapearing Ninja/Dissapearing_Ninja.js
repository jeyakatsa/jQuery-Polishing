$(document).ready(function(){

    $("img").click(function(){
        $(this).hide(100);
    })

    $("button").click(function(){
        $("img").show(500);
    })
})