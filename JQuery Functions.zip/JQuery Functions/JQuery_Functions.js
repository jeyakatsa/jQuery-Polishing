$(document).ready(function(){
    $('.click button').click(function(){
        $('.click p').css(
            'color', 'rgb(113, 194, 113)'
            )
    })
    $('.hide button').click(function(){
        $(".hide p").hide()
    })
    $('.show button').click(function(){
        $(".hide p").show()
    })
    $('.toggle button').click(function(){
        $(".toggle p").toggle()
    })
    $('.slideDown button').click(function(){
        $(".slideUp p:hidden").first().slideDown("slow")
    })
    $('.slideUp button').click(function(){
        $(".slideUp p").slideUp("slow")
    })
    $('.slideToggle button').click(function(){
        $(".slideToggle p").slideToggle("slow")
    })
    $('.fadeIn button').click(function(){
        $(".fadeOut p:hidden").fadeIn("slow")
    })
    $('.fadeOut button').click(function(){
        $(".fadeOut p").fadeOut("slow")
    })
    $('.addClass button').click(function(){
        $(".addClass p").addClass("green")
    })
    $('.before button').click(function(){
        $(".before p").before("<h1>Another sentence.</h1>")
    })
    $('.after button').click(function(){
        $(".after p").after("<h1>Another sentence.</h1>")
    })
    $('.append button').click(function(){
        $(".append p").append("<span>.</span>")
    })
    $('.html button').click(function(){
        $(".html p").html("<h1>p</h1>")
    })

    // bottom function needs to be further developed.
    $('.attr button').click(function(){
        $(".attr").attr("class")
    })
    //

    $('.val').click(function(){
        console.log($(".val p").val())
    })
    $('.text').click(function(){
        $(".text p").text("hello")
    })
})