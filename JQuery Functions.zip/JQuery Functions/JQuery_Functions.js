$(document).ready(function(){
    $('.click button').click(function(){
        $('.click p').css(
            'color', 'rgb(113, 194, 113)'
            )
    })
    $('.hide button').click(function(){
        $(".hide p").hide()
    })
    $('.show button').click(function(){
        $(".hide p").show()
    })
    $('.toggle button').click(function(){
        $(".toggle p").toggle()
    })
    //
    // buttom function needs to be further developed.
    $('.slideDown button').click(function(){
        $(".slideUp p:hidden").first().slideDown("slow");
    })
    //
    // buttom function needs to be further developed.
    $('.slideUp button').click(function(){
        $("#slideUp").slideUp()
    })
    //
    // buttom function needs to be further developed.
    $('.slideToggle').click(function(){
        $("#slideToggle").slideToggle()
    })
    //
    // buttom function needs to be further developed.
    $('.fadeIn button').click(function(){
        if ($(".fadeOut p").first().is("display", "none")) {
            $(".fadeOut p").fadeIn("slow");
          }
    })
    //
    // buttom function needs to be further developed.
    $('.fadeOut button').click(function(){
        $(".fadeOut P").fadeOut()
    })
    //

    $('.addClass button').click(function(){
        $(".addClass p").addClass("green")
    })
    $('.before button').click(function(){
        $(".before p").before("<h1>Another sentence.</h1>")
    })
    $('.after button').click(function(){
        $(".after p").after("<h1>Another sentence.</h1>")
    })
    $('.append button').click(function(){
        $(".append p").append("<span>.</span>")
    })
    $('.html button').click(function(){
        $(".html p").html("<h1>p</h1>")
    })

    // bottom function needs to be further developed.
    $('.attr button').click(function(){
        var classVal = $(".attr").attr("class")
        $('.attr').append(classVal)
    })
    //

    $('.val').click(function(){
        console.log($(".val p").val())
    })
    $('.text').click(function(){
        $(".text p").text("hello")
    })
})